
const getAllBlog  = "GET_ALL_BLOGS";
const gotAllBlog  = "GOT_ALL_BLOGS";
const getActiveBlog  = "GET_ACTIVE_BLOGS";
const getActiveComments  = "GET_ACTIVE_BLOG_COMMENTS";
const postNewBlog  = "POST_NEW_BLOG";
const postNewComment  = "POST_NEW_COMMENT";
const editBlog  = "EDIT_ACTIVE_BLOG";


export const actions = {
    getAllBlog: getAllBlog,
    getActiveBlog: getActiveBlog,
    getActiveComments: getActiveComments,
    postNewBlog: postNewBlog,
    postNewComment: postNewComment,
    editBlog: editBlog
}