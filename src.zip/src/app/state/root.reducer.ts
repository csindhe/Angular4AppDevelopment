import {state} from './app.state'
import { Blog } from '../blog/blog.model';
import { BlogComment } from '../comments/comment.model';
import { actions } from "./actions";

export function rootReducer(state:state ={}, action){
    return {
        blogs: allBlogs(state.blogs, action) ,
        activeBlog: activeBlog(state.activeBlog, action),
        activeComments: activeComments(state.activeComments, action),
        newBlog: newBlog(state.newBlog, action),
        newComment: newComment(state.newComment, action)
    }
}


//reducer for all blogs
function allBlogs(state=[], action): Blog[]{
    let type = action.type;
    switch(type){
        case "GET_ALL_BLOGS":
            return action.payload;
        default: 
            return state;
    }
}

//reducer for active blog
function activeBlog(state= {}, action): Blog{
    let type = action.type;
    switch(type){
        case actions.getActiveBlog:
            return action.payload;
        default: 
            return state;
    }
}

//reducer for active comments
function activeComments(state= [], action ): BlogComment[]{
    let type = action.type;
    switch(type){
        case actions.getActiveComments:
            return action.payload;
        default: 
            return state;
    }
}

//reducer for newBlog
function newBlog (state = {}, action): Blog {
    let type = action.type;
    switch(type){
        case actions.postNewBlog:
            return action.payload;
        default: 
            return state;
    }
}

//reducer for new Comment
function newComment (state = {}, action ): BlogComment{
    let type = action.type;
    switch(type){
        case actions.postNewComment:
            return action.payload;
        default: 
            return state;
    }
}