import * as Redux from "redux";
import { Blog } from "../blog/blog.model";
import { BlogComment } from "../comments/comment.model";
import { rootReducer } from "./root.reducer";

export interface state {
    blogs?: Blog[],
    activeBlog?: Blog,
    activeComments?: BlogComment[],
    newBlog?: Blog,
    newComment?: BlogComment
}

export let AppState = {
    store: Redux.createStore(rootReducer)
};